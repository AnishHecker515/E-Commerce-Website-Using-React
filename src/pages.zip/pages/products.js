// import { useState, useEffect } from "react";
// import { Link } from "react-router-dom";
// import SideBar from "./sidebar";
// function Products() {
//   const [products, setProducts] = useState([]);

//   useEffect(() => {
//     fetch("https://dummyjson.com/products")
//       .then((res) => res.json())
//       .then((d) => {
//         setProducts(d.products);
//       });
//   }, []);

//   console.log(products);

//   return (
//     <>
//       <div className="product-view">
//         <div className="container">
//           <div className="row">
//             <div className="col-md-9">
//               <div className="row">
//                 <div className="col-lg-12">
//                   <div className="row">
//                     <div className="col-md-8">
//                       <div className="product-search">
//                         <input type="text" placeholder="Search" />
//                         <button>
//                           <i className="fa fa-search" />
//                         </button>
//                       </div>
//                     </div>
//                     <div className="col-md-4">
//                       <div className="product-short">
//                         <div className="dropdown">
//                           <a
//                             href="#"
//                             className="dropdown-toggle"
//                             data-toggle="dropdown"
//                           >
//                             Product short by
//                           </a>
//                           <div className="dropdown-menu dropdown-menu-right">
//                             <a href="#" className="dropdown-item">
//                               Newest
//                             </a>
//                             <a href="#" className="dropdown-item">
//                               Popular
//                             </a>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>

//                 {products.map((ty) => (
//                   <div key={ty.id} className="col-lg-4">
//                     <div className="product-item">
//                       <div className="product-image">
//                        <Link to={`/single/${ty.id}`}>
//                           <img src={ty.thumbnail} alt={ty.title} />
//                         </Link>
//                         <div className="product-action">
//                           <a href="#">
//                             <i className="fa fa-cart-plus" />
//                           </a>
//                           <a href="#">
//                             <i className="fa fa-heart" />
//                           </a>
//                           <a href="#">
//                             <i className="fa fa-search" />
//                           </a>
//                         </div>
//                       </div>
//                       <div className="product-content">
//                         <div className="title">
//                           <a href="#">{ty.title}</a>
//                         </div>
//                         <div className="rating">
//                           {[...Array(Math.round(ty.rating)).keys()].map((star) => (
//                             <i key={star} className="fa fa-star" />
//                           ))}
//                         </div>
//                         <div className="price">
//                           ${ty.price} <span>{ty.discountPercentage}% off</span>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 ))}
//               </div>
//             </div>
//             <div className="col-lg-3">
//               <SideBar />
//             </div>
//           </div>
//         </div>
//       </div>
//     </>
//   );
// }

// export default Products;





// import { useState, useEffect } from "react";
// import { Link } from "react-router-dom";
// import SideBar from "./sidebar";

// function Products() {
//   const [products, setProducts] = useState([]);
//   const [query, setQuery] = useState("");
//   const [loading, setLoading] = useState(false);
  
//   useEffect(() => {
//     fetch("https://dummyjson.com/products")
//       .then((res) => res.json())
//       .then((d) => {
//         setProducts(d.products);
//       });
//   }, []);

//   const handleSearch = () => {
//     if (query) {
//       setLoading(true);
//       fetch(`https://dummyjson.com/products/search?q=${query}`)
//         .then((res) => res.json())
//         .then((data) => {
//           setProducts(data.products);
//         })
//         .catch((error) => {
//           console.error("Error fetching data:", error);
//         })
//         .finally(() => {
//           setLoading(false);
//         });
//     }
//   };

//   return (
//     <>
//       <div className="product-view">
//         <div className="container">
//           <div className="row">
//             <div className="col-md-9">
//               <div className="row">
//                 <div className="col-lg-12">
//                   <div className="row">
//                     <div className="col-md-8">
//                       <div className="product-search">
//                         <input
//                           type="text"
//                           placeholder="Search"
//                           value={query}
//                           onChange={(e) => setQuery(e.target.value)}
//                         />
//                         <button onClick={handleSearch}>
//                           <i className="fa fa-search" />
//                         </button>
//                       </div>
//                     </div>
//                     <div className="col-md-4">
//                       <div className="product-short">
//                         <div className="dropdown">
//                           <a
//                             href="#"
//                             className="dropdown-toggle"
//                             data-toggle="dropdown"
//                           >
//                             Product sort by
//                           </a>
//                           <div className="dropdown-menu dropdown-menu-right">
//                             <a href="#" className="dropdown-item">
//                               Newest
//                             </a>
//                             <a href="#" className="dropdown-item">
//                               Popular
//                             </a>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>

//                 {/* Display Loading */}
//                 {loading ? (
//                   <div>Loading...</div>
//                 ) : (
//                   products.map((ty) => (
//                     <div key={ty.id} className="col-lg-4">
//                       <div className="product-item">
//                         <div className="product-image">
//                           <Link to={`/single/${ty.id}`}>
//                             <img src={ty.thumbnail} alt={ty.title} />
//                           </Link>
//                           <div className="product-action">
//                             <a href="#">
//                               <i className="fa fa-cart-plus" />
//                             </a>
//                             <a href="#">
//                               <i className="fa fa-heart" />
//                             </a>
//                             <a href="#">
//                               <i className="fa fa-search" />
//                             </a>
//                           </div>
//                         </div>
//                         <div className="product-content">
//                           <div className="title">
//                             <a href="#">{ty.title}</a>
//                           </div>
//                           <div className="rating">
//                             {[...Array(Math.round(ty.rating)).keys()].map((star) => (
//                               <i key={star} className="fa fa-star" />
//                             ))}
//                           </div>
//                           <div className="price">
//                             ${ty.price} <span>{ty.discountPercentage}% off</span>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   ))
//                 )}
//               </div>
//             </div>
//             <div className="col-lg-3">
//               <SideBar />
//             </div>
//           </div>
//         </div>
//       </div>
//     </>
//   );
// }

// export default Products;







import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import SideBar from "./sidebar";

function Products() {
  const [products, setProducts] = useState([]);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [sortType, setSortType] = useState("asc"); // Default sorting by ascending price

  // Fetch products and apply sort by price
  useEffect(() => {
    setLoading(true);
    fetch(`https://dummyjson.com/products?sortBy=price&order=${sortType}`)
      .then((res) => res.json())
      .then((d) => {
        setProducts(d.products);
      })
      .catch((error) => console.error("Error fetching products:", error))
      .finally(() => setLoading(false));
  }, [sortType]);

  // Handle search functionality
  const handleSearch = () => {
    if (query) {
      setLoading(true);
      fetch(`https://dummyjson.com/products/search?q=${query}`)
        .then((res) => res.json())
        .then((data) => {
          setProducts(data.products);
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
        })
        .finally(() => {
          setLoading(false);
        });
    }
  };

  // Handle sorting by ascending or descending price
  const handleSort = (order) => {
    setSortType(order);
  };

  return (
    <>
      <div className="product-view">
        <div className="container">
          <div className="row">
            <div className="col-md-9">
              <div className="row">
                <div className="col-lg-12">
                  <div className="row">
                    <div className="col-md-8">
                      <div className="product-search">
                        <input
                          type="text"
                          placeholder="Search"
                          value={query}
                          onChange={(e) => setQuery(e.target.value)}
                        />
                        <button onClick={handleSearch}>
                          <i className="fa fa-search" />
                        </button>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="product-short">
                        <div className="dropdown">
                          <a
                            href="#"
                            className="dropdown-toggle"
                            data-toggle="dropdown"
                          >
                            Sort by Price
                          </a>
                          <div className="dropdown-menu dropdown-menu-right">
                            <a
                              href="#"
                              className="dropdown-item"
                              onClick={() => handleSort("asc")}
                            >
                              Lowest Price
                              <i className="fa fa-sort-amount-asc ml-2" />
                            </a>
                            <a
                              href="#"
                              className="dropdown-item"
                              onClick={() => handleSort("desc")}
                            >
                              Highest Price
                              <i className="fa fa-sort-amount-desc ml-2" />
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Display Loading */}
                {loading ? (
                  <div>Loading...</div>
                ) : (
                  products.map((product) => (
                    <div key={product.id} className="col-lg-4">
                      <div className="product-item">
                        <div className="product-image">
                          <Link to={`/single/${product.id}`}>
                            <img src={product.thumbnail} alt={product.title} />
                          </Link>
                          <div className="product-action">
                            <a href="#">
                              <i className="fa fa-cart-plus" />
                            </a>
                            <a href="#">
                              <i className="fa fa-heart" />
                            </a>
                            <a href="#">
                              <i className="fa fa-search" />
                            </a>
                          </div>
                        </div>
                        <div className="product-content">
                          <div className="title">
                            <a href="#">{product.title}</a>
                          </div>
                          <div className="rating">
                            {[...Array(Math.round(product.rating)).keys()].map(
                              (star) => (
                                <i key={star} className="fa fa-star" />
                              )
                            )}
                          </div>
                          <div className="price">
                            ${product.price.toFixed(2)}{" "}
                            <span>{product.discountPercentage}% off</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
            <div className="col-lg-3">
              <SideBar />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Products;
