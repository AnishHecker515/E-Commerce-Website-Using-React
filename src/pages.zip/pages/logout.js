function Logout() {
    return ( 
        <>
        <h1> Hi</h1>
        </>
     );
}

export default Logout;